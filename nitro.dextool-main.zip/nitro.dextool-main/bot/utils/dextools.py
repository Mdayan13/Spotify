import aiohttp
from aiohttp_socks import ProxyConnector
from typing import Dict, Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DexToolsAPI:
    BASE_URL = "https://core-api.dextools.io"
    
    def __init__(self, proxy: Optional[str] = None):
        proxy_url = proxy if proxy else "socks5://93.127.198.95:8090"
        logger.info(f"Initializing DexToolsAPI with proxy: {proxy_url}")
        self.connector = ProxyConnector.from_url(proxy_url)
        self.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json', 
            'Sec-Fetch-Site': 'same-site',
            'Accept-Language': 'en-GB,en;q=0.9',
            'Sec-Fetch-Mode': 'cors',
            'Origin': 'https://www.dextools.io',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15',
            'Referer': 'https://www.dextools.io/',
            'Connection': 'keep-alive',
            'Host': 'core-api.dextools.io',
            'Sec-Fetch-Dest': 'empty',
            'Priority': 'u=3, i',
            'X-API-Version': '1'
        }
        self.session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        logger.info("Creating new session with proxy connector")
        self.session = aiohttp.ClientSession(headers=self.headers, connector=self.connector)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            logger.info("Closing session and proxy connector")
            await self.session.close()
            await self.connector.close()

    async def _make_request(self, endpoint: str, params: Dict = None) -> Dict:
        """Make an async HTTP request to the DexTools API with proxy support"""
        if not self.session:
            raise RuntimeError("API client not initialized. Use 'async with' context manager.")
        
        full_url = f"{self.BASE_URL}{endpoint}"
        logger.info(f"Making request to: {full_url} with params: {params}")
        
        try:
            async with self.session.get(
                full_url,
                params=params
            ) as response:
                status = response.status
                logger.info(f"Response status: {status}")
                response_text = await response.text()
                logger.debug(f"Response body: {response_text}")
                response.raise_for_status()
                return await response.json()
        except Exception as e:
            logger.error(f"Request failed: {str(e)}")
            raise

    async def get_token_race(self, lite: bool = False) -> Dict:
        params = {"lite": str(lite).lower()}
        return await self._make_request("/pool/listing/token-race", params)


async def get_token_race(lite: bool = False) -> Dict:
    async with DexToolsAPI() as api:
        return await api.get_token_race(lite)
